Deedy-Cover-Letter
=========================

Clean and professional looking cover letter based on Deedy Resume.